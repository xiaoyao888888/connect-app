#ifndef __BLUETOOTH_PAN_H__
#define __BLUETOOTH_PAN_H__

#include <RkBtBase.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif
